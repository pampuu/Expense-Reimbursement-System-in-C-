﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Expense_Reimbursement_System
{
    public partial class Form1 : Form
    {
        private List<ExpenseClaim> claimsList = new List<ExpenseClaim>();
        private string filePath = "claims.csv";

        public Form1()
        {
            InitializeComponent();
            InitializeDataGridView();
            InitializeComboBoxes();
            LoadClaimsFromCSV();
        }

        private void InitializeDataGridView()
        {
            dgvClaims.ColumnCount = 6;
            dgvClaims.Columns[0].Name = "Claim ID";
            dgvClaims.Columns[1].Name = "Date";
            dgvClaims.Columns[2].Name = "Description";
            dgvClaims.Columns[3].Name = "Category";
            dgvClaims.Columns[4].Name = "Amount";
            dgvClaims.Columns[5].Name = "Status";
            dgvClaims.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void InitializeComboBoxes()
        {
            cmbCategory.Items.AddRange(new string[] { "Travel", "Food", "Accommodation", "Office Supplies" });
            cmbCategory.SelectedIndex = 0;
            cmbStatus.Items.AddRange(new string[] { "Pending", "Approved", "Rejected" });
            cmbStatus.SelectedIndex = 0;
        }

        private void LoadClaimsFromCSV()
        {
            if (!File.Exists(filePath))
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    writer.WriteLine("ClaimID,Date,Description,Category,Amount,Status");
                }
                return;
            }

            claimsList.Clear();
            dgvClaims.Rows.Clear();
            var lines = File.ReadAllLines(filePath).Skip(1); // Skip header

            foreach (var line in lines)
            {
                var data = line.Split(',');
                if (data.Length == 6)
                {
                    if (decimal.TryParse(data[4], out decimal amount))
                    {
                        claimsList.Add(new ExpenseClaim
                        {
                            ClaimID = data[0],
                            Date = data[1],
                            Description = data[2],
                            Category = data[3],
                            Amount = amount,
                            Status = data[5]
                        });
                    }
                }
            }
            RefreshDataGridView();
        }

        private void SaveClaimsToCSV()
        {
            var lines = new List<string> { "ClaimID,Date,Description,Category,Amount,Status" }; // Header
            lines.AddRange(claimsList.Select(c => $"{c.ClaimID},{c.Date},{c.Description},{c.Category},{c.Amount},{c.Status}"));
            File.WriteAllLines(filePath, lines);
        }

        private void RefreshDataGridView()
        {
            dgvClaims.Rows.Clear();
            foreach (var claim in claimsList)
            {
                dgvClaims.Rows.Add(claim.ClaimID, claim.Date, claim.Description, claim.Category, claim.Amount, claim.Status);
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClaimID.Text) || string.IsNullOrWhiteSpace(txtAmount.Text))
            {
                MessageBox.Show("Claim ID and Amount are required.");
                return;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                MessageBox.Show("Please enter a valid amount.");
                return;
            }

            ExpenseClaim newClaim = new ExpenseClaim
            {
                ClaimID = txtClaimID.Text,
                Date = txtDate.Text,
                Description = txtDescription.Text,
                Category = cmbCategory.Text,
                Amount = amount,
                Status = cmbStatus.Text
            };

            claimsList.Add(newClaim);
            SaveClaimsToCSV();
            RefreshDataGridView();
            MessageBox.Show("Claim added successfully!");
        }

        private void btnModify_Click_1(object sender, EventArgs e)
        {
            if (dgvClaims.SelectedRows.Count > 0 && dgvClaims.SelectedRows[0].Cells[0].Value != null)
            {
                int selectedIndex = dgvClaims.SelectedRows[0].Index;

                if (!decimal.TryParse(txtAmount.Text, out decimal amount))
                {
                    MessageBox.Show("Invalid amount entered.");
                    return;
                }

                claimsList[selectedIndex] = new ExpenseClaim
                {
                    ClaimID = txtClaimID.Text,
                    Date = txtDate.Text,
                    Description = txtDescription.Text,
                    Category = cmbCategory.Text,
                    Amount = amount,
                    Status = cmbStatus.Text
                };

                SaveClaimsToCSV();
                RefreshDataGridView();
                MessageBox.Show("Claim modified successfully!");
            }
            else
            {
                MessageBox.Show("Please select a claim to modify.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvClaims.SelectedRows.Count > 0 && dgvClaims.SelectedRows[0].Cells[0].Value != null)
            {
                string selectedClaimID = dgvClaims.SelectedRows[0].Cells[0].Value.ToString();
                claimsList = claimsList.Where(c => c.ClaimID != selectedClaimID).ToList();

                SaveClaimsToCSV();
                RefreshDataGridView();
                MessageBox.Show("Claim deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a claim to delete.");
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (dgvClaims.SelectedRows.Count > 0 && dgvClaims.SelectedRows[0].Cells[0].Value != null)
            {
                string selectedClaimID = dgvClaims.SelectedRows[0].Cells[0].Value.ToString();

                foreach (var claim in claimsList)
                {
                    if (claim.ClaimID == selectedClaimID)
                    {
                        claim.Status = "Approved";
                        break;
                    }
                }

                SaveClaimsToCSV();
                RefreshDataGridView();
                MessageBox.Show("Claim approved successfully!");
            }
            else
            {
                MessageBox.Show("Please select a claim to approve.");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text.Trim().ToLower();

            var filteredClaims = claimsList.Where(c =>
                c.ClaimID.ToLower().Contains(searchQuery) ||
                c.Description.ToLower().Contains(searchQuery) ||
                c.Category.ToLower().Contains(searchQuery) ||
                c.Status.ToLower().Contains(searchQuery)
            ).ToList();

            dgvClaims.Rows.Clear();
            foreach (var claim in filteredClaims)
            {
                dgvClaims.Rows.Add(claim.ClaimID, claim.Date, claim.Description, claim.Category, claim.Amount, claim.Status);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadClaimsFromCSV();
            MessageBox.Show("Claims loaded successfully!");
        }

        public class ExpenseClaim
        {
            public string ClaimID { get; set; }
            public string Date { get; set; }
            public string Description { get; set; }
            public string Category { get; set; }
            public decimal Amount { get; set; }
            public string Status { get; set; }
        }

       
    }
}
